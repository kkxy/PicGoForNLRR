<?php
// 连接数据库
$servername = "localhost";
$username = "nlrr";
$password = "Wan211314";
$dbname = "tools";
$tbname = "xinghuouser";
$key = md5("NlrrsCustomMiYao");//对密钥进行MD5加密

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("数据库连接失败: " . $conn->connect_error);
}

// AES加密
function encrypt($str, $key) {
    $iv_size = openssl_cipher_iv_length('AES-256-CBC');
    $iv = openssl_random_pseudo_bytes($iv_size); // 生成随机IV
    $encrypted_str = openssl_encrypt(mb_convert_encoding($str, 'UTF-8'), 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
    $result = base64_encode($iv . $encrypted_str);
    return $result;
}

// AES解密
function decrypt($encrypted_str, $key) {
    $encrypted_str = base64_decode($encrypted_str);
    $iv_size = openssl_cipher_iv_length('AES-256-CBC');
    $iv = substr($encrypted_str, 0, $iv_size);
    $encrypted_str = substr($encrypted_str, $iv_size);
    $result = openssl_decrypt($encrypted_str, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
    return mb_convert_encoding($result, 'UTF-8', 'UTF-8');
}

// 处理表单提交
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $username = $_POST["username"];
  $password = $_POST["password"];

	// 查询数据库
	$stmt = $conn->prepare("SELECT * FROM {$tbname} WHERE loginname=? and password=?");
	$stmt->bind_param("ss", $username, $password);
	$stmt->execute();
	$result = $stmt->get_result();
	
  if ($result->num_rows > 0) {
    // 用户存在且密码正确    
	$row = $result->fetch_assoc();
	$returuncontent = "username:".$row["loginname"]."-ExpireTime:".$row["expiretime"]."-Status:".$row["status"]."-LastLoginTime:".$row["lastlogintime"]."-LastIP:".$row["lastip"]."-";
	$returuncontent = encrypt($returuncontent, $key);
	
  } else {
    // 用户不存在或密码不正确
    $returuncontent = "登录失败，请检查用户名和密码。";
  }
}
echo $returuncontent;


?>