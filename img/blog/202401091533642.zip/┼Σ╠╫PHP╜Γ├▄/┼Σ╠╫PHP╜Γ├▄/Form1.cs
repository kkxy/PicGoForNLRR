﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;


namespace 配套PHP解密
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public string Key = "";


        private void Form1_Load(object sender, EventArgs e)
        {

        }


        public class AESEncryption
        {
            public static string DecryptStringFromBase64(string base64String, string key)
            {
                byte[] encryptedData = Convert.FromBase64String(base64String);
                using (Aes aes = Aes.Create())
                {
                    aes.Key = Encoding.UTF8.GetBytes(key);
                    aes.IV = encryptedData.Take(16).ToArray();

                    using (var decryptor = aes.CreateDecryptor(aes.Key, aes.IV))
                    using (var ms = new System.IO.MemoryStream(encryptedData.Skip(16).ToArray()))
                    using (var cs = new System.Security.Cryptography.CryptoStream(ms, decryptor, System.Security.Cryptography.CryptoStreamMode.Read))
                    using (var sr = new System.IO.StreamReader(cs))
                    {
                        return sr.ReadToEnd();
                    }
                }
            }
        }

        private static string GetMd5Hash(MD5 md5Hash, string input)
        {
            byte[] data = md5Hash.ComputeHash(Encoding.UTF8.GetBytes(input));

            StringBuilder sBuilder = new StringBuilder();

            for (int i = 0; i < data.Length; i++)
            {
                sBuilder.Append(data[i].ToString("x2"));
            }

            return sBuilder.ToString();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            string originalString = "NlrrsCustomMiYao"; // 替换为要加密的原始字符串

            using (MD5 md5Hash = MD5.Create())
            {
                string hashedString = GetMd5Hash(md5Hash, originalString);
                textBox2.Text = hashedString;
                Key = hashedString;
            }



            string encryptedStr = textBox1.Text.Trim(); // 替换为PHP加密后的内容

            string decryptedStr = AESEncryption.DecryptStringFromBase64(encryptedStr, Key);
            textBox3.Text = decryptedStr;//解密后的内容
        }
    }
}
